Rails.application.routes.draw do

    get 'home', to: 'home#index', as: :home
    get 'home/about', to: 'home#about', as: :about
    get 'home/contact', to: 'home#contact', as: :contact
    get 'home/privacy', to: 'home#privacy', as: :privacy

   
    get 'assignments', to: 'assignments#index', as: :assignments
    get 'assignments/new', to: 'assignments#new', as: :new_assignment
    get '/assignments/:id', to: 'assignments#show', as: :assignment
    get '/assignments/:id/edit', to: 'assignments#edit', as: :edit_assignment
    post 'assignments', to: 'assignments#create'
    patch 'assignments/:id', to: 'assignments#update'
    delete 'assignments/:id', to: 'assignments#destroy'

    get 'employees', to: 'employees#index', as: :employees
    get 'employees/new', to: 'employees#new', as: :new_employee
    get '/employees/:id', to: 'employees#show', as: :employee
    get '/employees/:id/edit', to: 'employees#edit', as: :edit_employee
    post 'employees', to: 'employees#create'
    patch 'employees/:id', to: 'employees#update'
    delete 'employees/:id', to: 'employees#destroy'

    get 'stores', to: 'stores#index', as: :stores
    get 'stores/new', to: 'stores#new', as: :new_store
    get '/stores/:id', to: 'stores#show', as: :store
    get '/stores/:id/edit', to: 'stores#edit', as: :edit_store
    post 'stores', to: 'stores#create'
    patch 'stores/:id', to: 'stores#update'
    delete 'stores/:id', to: 'stores#destroy'
   

    root :to => 'home#index'


end
