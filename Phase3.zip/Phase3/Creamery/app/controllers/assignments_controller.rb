class AssignmentsController < ApplicationController
    before_action :set_assignment, only: [:show, :edit, :destroy]

  def index
      @current_assignments = Assignment.current.chronological.paginate(page: params[:page]).per_page(10)
      @past_assignments = Assignment.past.chronological.paginate(page: params[:page]).per_page(10)
  end

  def new
    @assignment = Assignment.new
    @assignment.employee_id = params[:employee_id] unless params[:employee_id].nil?
  end

  def create
    @assignment = Assignment.new(assignment_params)
    if @assignment.save
      redirect_to assignments_path, notice: "Successfully created assignment."
    else
      render action: 'new'
    end
  end


  def destroy
    @assignment.destroy
    redirect_to assignments_path, notice: "Successfully removed assignment."
  end

  private


  def assignment_params
    params.require(:assignment).permit(:store_id, :employee_id, :start_date)
  end

  def set_assignment
    @assignment = Assignment.find(params[:id])
  end

end
